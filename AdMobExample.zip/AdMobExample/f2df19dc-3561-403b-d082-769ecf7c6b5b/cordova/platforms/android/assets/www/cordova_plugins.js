cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/org.apache.cordova.inappbrowser/www/inappbrowser.js",
        "id": "org.apache.cordova.inappbrowser.inappbrowser",
        "clobbers": [
            "window.open"
        ]
    },
    {
        "file": "plugins/com.rjfun.cordova.plugin.admob/www/AdMob.js",
        "id": "com.rjfun.cordova.plugin.admob.AdMob",
        "clobbers": [
            "window.plugins.AdMob"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "org.apache.cordova.console": "0.2.13",
    "com.msopentech.websql": "0.0.7",
    "org.apache.cordova.inappbrowser": "0.6.0",
    "com.rjfun.cordova.plugin.admob": "2.1.7",
    "com.google.playservices": "19.0.0",
    "com.google.admobsdk": "6.12.2"
}
// BOTTOM OF METADATA
});