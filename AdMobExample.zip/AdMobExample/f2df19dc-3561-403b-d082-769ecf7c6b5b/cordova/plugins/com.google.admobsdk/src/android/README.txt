
<dependency id="android.support.v4@21.0.1" url="https://github.com/MobileChromeApps/cordova-plugin-android-support-v4" />
<dependency id="com.google.playservices@19.0.0" url="https://github.com/MobileChromeApps/google-play-services" />
